var express = require('express');
var fs = require('fs');
var	path = require('path');
var logger = require('morgan');
var http = require('http');
var cl_services = require('./collector-modules/cl_services');

var app = express();

app.set('port', process.env.PORT || 3000);
app.use(logger('combined'));  /* 'default', 'short', 'tiny', 'dev' */
//app.use(express.bodyParser()), //da capire che fa
app.use(express.static(path.join(__dirname, 'html')));

// route to pages
app.use('/html', function (request, response) {
    //console.log("request starting...");
	
	var filePath = './html' + request.url;
	if (filePath == './')
		filePath += 'index.html';
	
	var extname = path.extname(filePath);
	var contentType = 'text/html';
	switch (extname) {
		case '.js':
			contentType = 'text/javascript';
			break;
		case '.css':
			contentType = 'text/css';
			break;
	}
	
	fs.exists(filePath, function(exists) {	
		if (exists) {
			fs.readFile(filePath, function(error, content) {
				if (error) {
					response.status(500).send();
				}
				else {
					response.set('Content-Type', 'text/html');
					response.status(200).send(content);
				}
			});
		}
		else {
			response.status(404).send();
		}
	});
});

// route to REST services
app.post('/collector/add', cl_services.addPoint);
app.get('/collector/points', cl_services.findAll);

http.createServer(app).listen(app.get('port'), function () {
    console.log("Express server listening on port " + app.get('port') + " YEAH!!!");
    //print("Arrived!");
});

