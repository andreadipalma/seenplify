exports.findAll = function(req, res) {
};

exports.addPoint = function(req, res) {
  
  
};